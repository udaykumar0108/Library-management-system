-- Library Management System Database Schema
-- Run this file to set up the database

CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

-- Books Table
CREATE TABLE IF NOT EXISTS books (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(200) NOT NULL,
    author          VARCHAR(100) NOT NULL,
    isbn            VARCHAR(20) UNIQUE,
    category        VARCHAR(50),
    total_copies    INT DEFAULT 1,
    available_copies INT DEFAULT 1,
    publisher       VARCHAR(100),
    published_year  INT,
    description     TEXT
);

-- Members Table
CREATE TABLE IF NOT EXISTS members (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    name                VARCHAR(100) NOT NULL,
    email               VARCHAR(100) UNIQUE,
    phone               VARCHAR(15),
    address             TEXT,
    membership_type     VARCHAR(20) DEFAULT 'PUBLIC',
    membership_date     DATE,
    membership_expiry   DATE,
    status              VARCHAR(20) DEFAULT 'ACTIVE'
);

-- Borrow Records Table
CREATE TABLE IF NOT EXISTS borrow_records (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    member_id   INT NOT NULL,
    book_id     INT NOT NULL,
    borrow_date DATE NOT NULL,
    due_date    DATE NOT NULL,
    return_date DATE,
    status      VARCHAR(20) DEFAULT 'BORROWED',
    fine        DOUBLE DEFAULT 0.0,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id)   REFERENCES books(id)   ON DELETE CASCADE
);

-- Sample seed data
INSERT INTO books (title, author, isbn, category, total_copies, available_copies, publisher, published_year)
VALUES
('Clean Code',               'Robert C. Martin', '978-0132350884', 'Programming',  3, 3, 'Prentice Hall', 2008),
('The Pragmatic Programmer', 'Andrew Hunt',       '978-0135957059', 'Programming',  2, 2, 'Addison-Wesley', 2019),
('Design Patterns',          'Gang of Four',      '978-0201633610', 'Programming',  2, 2, 'Addison-Wesley', 1994),
('Head First Java',          'Kathy Sierra',      '978-0596009205', 'Java',         4, 4, 'OReilly Media',  2005),
('Effective Java',           'Joshua Bloch',      '978-0134685991', 'Java',         3, 3, 'Addison-Wesley', 2018),
('Spring in Action',         'Craig Walls',       '978-1617294945', 'Java',         2, 2, 'Manning',        2018),
('Database Design',          'Adrienne Watt',     '978-1774200360', 'Database',     3, 3, 'BCcampus',       2014),
('Introduction to Algorithms','Thomas Cormen',    '978-0262033848', 'Algorithms',   2, 2, 'MIT Press',      2009);

INSERT INTO members (name, email, phone, address, membership_type, membership_date, membership_expiry, status)
VALUES
('Uday Kumar',    'uday@mail.com',    '9000000001', 'Hyderabad', 'STUDENT', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 YEAR), 'ACTIVE'),
('Priya Reddy',   'priya@mail.com',   '9000000002', 'Hyderabad', 'STUDENT', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 YEAR), 'ACTIVE'),
('Ravi Shankar',  'ravi@mail.com',    '9000000003', 'Secunderabad', 'STAFF', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 2 YEAR), 'ACTIVE'),
('Anita Rao',     'anita@mail.com',   '9000000004', 'Hyderabad', 'PUBLIC',  CURDATE(), DATE_ADD(CURDATE(), INTERVAL 1 YEAR), 'ACTIVE');
