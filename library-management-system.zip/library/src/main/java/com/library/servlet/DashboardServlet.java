package com.library.servlet;

import com.library.dao.BookDAO;
import com.library.dao.BorrowDAO;
import com.library.dao.MemberDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    private final BookDAO bookDAO = new BookDAO();
    private final MemberDAO memberDAO = new MemberDAO();
    private final BorrowDAO borrowDAO = new BorrowDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setAttribute("totalBooks", bookDAO.countBooks());
        req.setAttribute("activeMembers", memberDAO.countActiveMembers());
        req.setAttribute("activeIssues", borrowDAO.countActiveIssues());
        req.setAttribute("overdueCount", borrowDAO.getOverdueRecords().size());
        req.setAttribute("recentRecords", borrowDAO.getAllRecords()
                .stream().limit(5).toList());

        req.getRequestDispatcher("/WEB-INF/views/dashboard.jsp").forward(req, resp);
    }
}
