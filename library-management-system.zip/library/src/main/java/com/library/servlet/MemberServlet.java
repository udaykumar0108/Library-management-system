package com.library.servlet;

import com.library.dao.MemberDAO;
import com.library.model.Member;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@WebServlet("/members/*")
public class MemberServlet extends HttpServlet {

    private final MemberDAO memberDAO = new MemberDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String pathInfo = req.getPathInfo();
        String action = (pathInfo == null || pathInfo.equals("/")) ? "list" : pathInfo.substring(1);

        switch (action) {
            case "list":
                listMembers(req, resp);
                break;
            case "add":
                req.getRequestDispatcher("/WEB-INF/views/members/add.jsp").forward(req, resp);
                break;
            case "edit":
                showEditForm(req, resp);
                break;
            case "delete":
                deleteMember(req, resp);
                break;
            case "search":
                searchMembers(req, resp);
                break;
            default:
                resp.sendRedirect(req.getContextPath() + "/members/");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String pathInfo = req.getPathInfo();
        String action = (pathInfo == null || pathInfo.equals("/")) ? "" : pathInfo.substring(1);

        switch (action) {
            case "add":
                addMember(req, resp);
                break;
            case "edit":
                updateMember(req, resp);
                break;
            default:
                resp.sendRedirect(req.getContextPath() + "/members/");
        }
    }

    private void listMembers(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        List<Member> members = memberDAO.getAllMembers();
        req.setAttribute("members", members);
        req.setAttribute("activeCount", memberDAO.countActiveMembers());
        req.getRequestDispatcher("/WEB-INF/views/members/list.jsp").forward(req, resp);
    }

    private void searchMembers(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String keyword = req.getParameter("keyword");
        List<Member> members = (keyword != null && !keyword.trim().isEmpty())
                ? memberDAO.searchMembers(keyword.trim())
                : memberDAO.getAllMembers();
        req.setAttribute("members", members);
        req.setAttribute("keyword", keyword);
        req.getRequestDispatcher("/WEB-INF/views/members/list.jsp").forward(req, resp);
    }

    private void addMember(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        try {
            Member member = extractMemberFromRequest(req);
            memberDAO.addMember(member);
            req.getSession().setAttribute("successMsg", "Member registered successfully!");
        } catch (Exception e) {
            req.getSession().setAttribute("errorMsg", "Error registering member: " + e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/members/");
    }

    private void showEditForm(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        Member member = memberDAO.getMemberById(id);
        if (member != null) {
            req.setAttribute("member", member);
            req.getRequestDispatcher("/WEB-INF/views/members/edit.jsp").forward(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/members/");
        }
    }

    private void updateMember(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        try {
            Member member = extractMemberFromRequest(req);
            member.setId(Integer.parseInt(req.getParameter("id")));
            memberDAO.updateMember(member);
            req.getSession().setAttribute("successMsg", "Member updated successfully!");
        } catch (Exception e) {
            req.getSession().setAttribute("errorMsg", "Error updating member: " + e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/members/");
    }

    private void deleteMember(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            memberDAO.deleteMember(id);
            req.getSession().setAttribute("successMsg", "Member deleted successfully!");
        } catch (Exception e) {
            req.getSession().setAttribute("errorMsg", "Error deleting member: " + e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/members/");
    }

    private Member extractMemberFromRequest(HttpServletRequest req) {
        Member member = new Member();
        member.setName(req.getParameter("name"));
        member.setEmail(req.getParameter("email"));
        member.setPhone(req.getParameter("phone"));
        member.setAddress(req.getParameter("address"));
        member.setMembershipType(req.getParameter("membershipType"));
        member.setMembershipDate(LocalDate.now());
        // Set expiry 1 year from today by default
        member.setMembershipExpiry(LocalDate.now().plusYears(1));
        member.setStatus("ACTIVE");
        return member;
    }
}
