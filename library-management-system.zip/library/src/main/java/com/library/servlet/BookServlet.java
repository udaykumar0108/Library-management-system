package com.library.servlet;

import com.library.dao.BookDAO;
import com.library.model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/books/*")
public class BookServlet extends HttpServlet {

    private final BookDAO bookDAO = new BookDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String pathInfo = req.getPathInfo();
        String action = (pathInfo == null || pathInfo.equals("/")) ? "list" : pathInfo.substring(1);

        switch (action) {
            case "list":
            case "":
                listBooks(req, resp);
                break;
            case "add":
                req.getRequestDispatcher("/WEB-INF/views/books/add.jsp").forward(req, resp);
                break;
            case "edit":
                showEditForm(req, resp);
                break;
            case "delete":
                deleteBook(req, resp);
                break;
            case "search":
                searchBooks(req, resp);
                break;
            default:
                resp.sendRedirect(req.getContextPath() + "/books/");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String pathInfo = req.getPathInfo();
        String action = (pathInfo == null || pathInfo.equals("/")) ? "" : pathInfo.substring(1);

        switch (action) {
            case "add":
                addBook(req, resp);
                break;
            case "edit":
                updateBook(req, resp);
                break;
            default:
                resp.sendRedirect(req.getContextPath() + "/books/");
        }
    }

    private void listBooks(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        List<Book> books = bookDAO.getAllBooks();
        req.setAttribute("books", books);
        req.setAttribute("totalBooks", bookDAO.countBooks());
        req.getRequestDispatcher("/WEB-INF/views/books/list.jsp").forward(req, resp);
    }

    private void searchBooks(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String keyword = req.getParameter("keyword");
        List<Book> books = (keyword != null && !keyword.trim().isEmpty())
                ? bookDAO.searchBooks(keyword.trim())
                : bookDAO.getAllBooks();
        req.setAttribute("books", books);
        req.setAttribute("keyword", keyword);
        req.getRequestDispatcher("/WEB-INF/views/books/list.jsp").forward(req, resp);
    }

    private void addBook(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        try {
            Book book = extractBookFromRequest(req);
            bookDAO.addBook(book);
            req.getSession().setAttribute("successMsg", "Book added successfully!");
        } catch (Exception e) {
            req.getSession().setAttribute("errorMsg", "Error adding book: " + e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/books/");
    }

    private void showEditForm(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        Book book = bookDAO.getBookById(id);
        if (book != null) {
            req.setAttribute("book", book);
            req.getRequestDispatcher("/WEB-INF/views/books/edit.jsp").forward(req, resp);
        } else {
            resp.sendRedirect(req.getContextPath() + "/books/");
        }
    }

    private void updateBook(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        try {
            Book book = extractBookFromRequest(req);
            book.setId(Integer.parseInt(req.getParameter("id")));
            bookDAO.updateBook(book);
            req.getSession().setAttribute("successMsg", "Book updated successfully!");
        } catch (Exception e) {
            req.getSession().setAttribute("errorMsg", "Error updating book: " + e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/books/");
    }

    private void deleteBook(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        try {
            int id = Integer.parseInt(req.getParameter("id"));
            bookDAO.deleteBook(id);
            req.getSession().setAttribute("successMsg", "Book deleted successfully!");
        } catch (Exception e) {
            req.getSession().setAttribute("errorMsg", "Error deleting book: " + e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/books/");
    }

    private Book extractBookFromRequest(HttpServletRequest req) {
        Book book = new Book();
        book.setTitle(req.getParameter("title"));
        book.setAuthor(req.getParameter("author"));
        book.setIsbn(req.getParameter("isbn"));
        book.setCategory(req.getParameter("category"));
        book.setTotalCopies(Integer.parseInt(req.getParameter("totalCopies")));
        book.setPublisher(req.getParameter("publisher"));
        book.setPublishedYear(Integer.parseInt(req.getParameter("publishedYear")));
        book.setDescription(req.getParameter("description"));
        return book;
    }
}
