package com.library.servlet;

import com.library.dao.BookDAO;
import com.library.dao.BorrowDAO;
import com.library.dao.MemberDAO;
import com.library.model.BorrowRecord;
import com.library.model.Member;
import com.library.model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

@WebServlet("/borrow/*")
public class BorrowServlet extends HttpServlet {

    private final BorrowDAO borrowDAO = new BorrowDAO();
    private final BookDAO bookDAO = new BookDAO();
    private final MemberDAO memberDAO = new MemberDAO();

    private static final int BORROW_DAYS = 14; // 2-week default borrow period

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String pathInfo = req.getPathInfo();
        String action = (pathInfo == null || pathInfo.equals("/")) ? "list" : pathInfo.substring(1);

        switch (action) {
            case "list":
                listRecords(req, resp);
                break;
            case "issue":
                showIssueForm(req, resp);
                break;
            case "return":
                showReturnForm(req, resp);
                break;
            case "overdue":
                showOverdue(req, resp);
                break;
            case "history":
                memberHistory(req, resp);
                break;
            default:
                resp.sendRedirect(req.getContextPath() + "/borrow/");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String pathInfo = req.getPathInfo();
        String action = (pathInfo == null || pathInfo.equals("/")) ? "" : pathInfo.substring(1);

        switch (action) {
            case "issue":
                issueBook(req, resp);
                break;
            case "return":
                returnBook(req, resp);
                break;
            default:
                resp.sendRedirect(req.getContextPath() + "/borrow/");
        }
    }

    private void listRecords(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        List<BorrowRecord> records = borrowDAO.getAllRecords();
        req.setAttribute("records", records);
        req.setAttribute("activeIssues", borrowDAO.countActiveIssues());
        req.setAttribute("overdueCount", borrowDAO.getOverdueRecords().size());
        req.getRequestDispatcher("/WEB-INF/views/borrow/list.jsp").forward(req, resp);
    }

    private void showIssueForm(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setAttribute("members", memberDAO.getAllMembers());
        req.setAttribute("books", bookDAO.getAvailableBooks());
        req.getRequestDispatcher("/WEB-INF/views/borrow/issue.jsp").forward(req, resp);
    }

    private void issueBook(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        try {
            int memberId = Integer.parseInt(req.getParameter("memberId"));
            int bookId = Integer.parseInt(req.getParameter("bookId"));

            // Validate member is active
            Member member = memberDAO.getMemberById(memberId);
            if (member == null || !member.isActive()) {
                req.getSession().setAttribute("errorMsg", "Member is not active or not found.");
                resp.sendRedirect(req.getContextPath() + "/borrow/issue");
                return;
            }

            // Check book availability
            Book book = bookDAO.getBookById(bookId);
            if (book == null || !book.isAvailable()) {
                req.getSession().setAttribute("errorMsg", "Book is not available for borrowing.");
                resp.sendRedirect(req.getContextPath() + "/borrow/issue");
                return;
            }

            // Create borrow record
            LocalDate today = LocalDate.now();
            LocalDate dueDate = today.plusDays(BORROW_DAYS);
            BorrowRecord record = new BorrowRecord(memberId, bookId, today, dueDate);

            borrowDAO.addRecord(record);
            bookDAO.decrementAvailable(bookId);

            req.getSession().setAttribute("successMsg",
                    "Book issued successfully! Due date: " + dueDate);

        } catch (Exception e) {
            req.getSession().setAttribute("errorMsg", "Error issuing book: " + e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/borrow/");
    }

    private void showReturnForm(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String memberIdParam = req.getParameter("memberId");
        if (memberIdParam != null) {
            int memberId = Integer.parseInt(memberIdParam);
            List<BorrowRecord> activeRecords = borrowDAO.getActiveByMember(memberId);
            req.setAttribute("activeRecords", activeRecords);
            req.setAttribute("memberId", memberId);
        }
        req.setAttribute("members", memberDAO.getAllMembers());
        req.getRequestDispatcher("/WEB-INF/views/borrow/return.jsp").forward(req, resp);
    }

    private void returnBook(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        try {
            int recordId = Integer.parseInt(req.getParameter("recordId"));
            BorrowRecord record = borrowDAO.getRecordById(recordId);

            if (record == null) {
                req.getSession().setAttribute("errorMsg", "Borrow record not found.");
                resp.sendRedirect(req.getContextPath() + "/borrow/return");
                return;
            }

            LocalDate returnDate = LocalDate.now();
            record.setReturnDate(returnDate);
            double fine = record.calculateFine();

            borrowDAO.returnBook(recordId, returnDate, fine);
            bookDAO.incrementAvailable(record.getBookId());

            String msg = "Book returned successfully!";
            if (fine > 0) msg += " Fine collected: ₹" + fine;
            req.getSession().setAttribute("successMsg", msg);

        } catch (Exception e) {
            req.getSession().setAttribute("errorMsg", "Error processing return: " + e.getMessage());
        }
        resp.sendRedirect(req.getContextPath() + "/borrow/");
    }

    private void showOverdue(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        List<BorrowRecord> overdueRecords = borrowDAO.getOverdueRecords();
        // Calculate current fines for display
        overdueRecords.forEach(BorrowRecord::calculateFine);
        req.setAttribute("overdueRecords", overdueRecords);
        req.getRequestDispatcher("/WEB-INF/views/borrow/overdue.jsp").forward(req, resp);
    }

    private void memberHistory(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        int memberId = Integer.parseInt(req.getParameter("memberId"));
        List<BorrowRecord> history = borrowDAO.getActiveByMember(memberId);
        req.setAttribute("history", history);
        req.setAttribute("member", memberDAO.getMemberById(memberId));
        req.getRequestDispatcher("/WEB-INF/views/borrow/history.jsp").forward(req, resp);
    }
}
