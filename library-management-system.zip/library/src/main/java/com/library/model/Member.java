package com.library.model;

import java.time.LocalDate;

public class Member {

    private int id;
    private String name;
    private String email;
    private String phone;
    private String address;
    private String membershipType; // STUDENT, STAFF, PUBLIC
    private LocalDate membershipDate;
    private LocalDate membershipExpiry;
    private String status; // ACTIVE, EXPIRED, SUSPENDED

    public Member() {}

    public Member(String name, String email, String phone, String address,
                  String membershipType, LocalDate membershipDate, LocalDate membershipExpiry) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.membershipType = membershipType;
        this.membershipDate = membershipDate;
        this.membershipExpiry = membershipExpiry;
        this.status = "ACTIVE";
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getMembershipType() { return membershipType; }
    public void setMembershipType(String membershipType) { this.membershipType = membershipType; }

    public LocalDate getMembershipDate() { return membershipDate; }
    public void setMembershipDate(LocalDate membershipDate) { this.membershipDate = membershipDate; }

    public LocalDate getMembershipExpiry() { return membershipExpiry; }
    public void setMembershipExpiry(LocalDate membershipExpiry) { this.membershipExpiry = membershipExpiry; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public boolean isActive() {
        return "ACTIVE".equals(status) && LocalDate.now().isBefore(membershipExpiry);
    }

    @Override
    public String toString() {
        return "Member{id=" + id + ", name='" + name + "', status='" + status + "'}";
    }
}
