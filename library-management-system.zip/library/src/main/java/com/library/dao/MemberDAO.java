package com.library.dao;

import com.library.model.Member;
import com.library.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {

    public boolean addMember(Member member) {
        String sql = "INSERT INTO members (name, email, phone, address, membership_type, " +
                     "membership_date, membership_expiry, status) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, member.getName());
            ps.setString(2, member.getEmail());
            ps.setString(3, member.getPhone());
            ps.setString(4, member.getAddress());
            ps.setString(5, member.getMembershipType());
            ps.setDate(6, Date.valueOf(member.getMembershipDate()));
            ps.setDate(7, Date.valueOf(member.getMembershipExpiry()));
            ps.setString(8, member.getStatus());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error adding member: " + e.getMessage(), e);
        }
    }

    public boolean updateMember(Member member) {
        String sql = "UPDATE members SET name=?, email=?, phone=?, address=?, " +
                     "membership_type=?, membership_expiry=?, status=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, member.getName());
            ps.setString(2, member.getEmail());
            ps.setString(3, member.getPhone());
            ps.setString(4, member.getAddress());
            ps.setString(5, member.getMembershipType());
            ps.setDate(6, Date.valueOf(member.getMembershipExpiry()));
            ps.setString(7, member.getStatus());
            ps.setInt(8, member.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error updating member: " + e.getMessage(), e);
        }
    }

    public boolean deleteMember(int id) {
        String sql = "DELETE FROM members WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error deleting member: " + e.getMessage(), e);
        }
    }

    public Member getMemberById(int id) {
        String sql = "SELECT * FROM members WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapMember(rs);

        } catch (SQLException e) {
            throw new RuntimeException("Error fetching member: " + e.getMessage(), e);
        }
        return null;
    }

    public List<Member> getAllMembers() {
        List<Member> members = new ArrayList<>();
        String sql = "SELECT * FROM members ORDER BY name";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) members.add(mapMember(rs));

        } catch (SQLException e) {
            throw new RuntimeException("Error fetching members: " + e.getMessage(), e);
        }
        return members;
    }

    public List<Member> searchMembers(String keyword) {
        List<Member> members = new ArrayList<>();
        String sql = "SELECT * FROM members WHERE LOWER(name) LIKE ? OR email LIKE ? OR phone LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String kw = "%" + keyword.toLowerCase() + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            ps.setString(3, kw);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) members.add(mapMember(rs));

        } catch (SQLException e) {
            throw new RuntimeException("Error searching members: " + e.getMessage(), e);
        }
        return members;
    }

    public int countActiveMembers() {
        String sql = "SELECT COUNT(*) FROM members WHERE status='ACTIVE' AND membership_expiry >= CURDATE()";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) return rs.getInt(1);

        } catch (SQLException e) {
            throw new RuntimeException("Error counting members: " + e.getMessage(), e);
        }
        return 0;
    }

    private Member mapMember(ResultSet rs) throws SQLException {
        Member m = new Member();
        m.setId(rs.getInt("id"));
        m.setName(rs.getString("name"));
        m.setEmail(rs.getString("email"));
        m.setPhone(rs.getString("phone"));
        m.setAddress(rs.getString("address"));
        m.setMembershipType(rs.getString("membership_type"));
        m.setMembershipDate(rs.getDate("membership_date").toLocalDate());
        m.setMembershipExpiry(rs.getDate("membership_expiry").toLocalDate());
        m.setStatus(rs.getString("status"));
        return m;
    }
}
