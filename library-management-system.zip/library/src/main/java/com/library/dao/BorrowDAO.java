package com.library.dao;

import com.library.model.BorrowRecord;
import com.library.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BorrowDAO {

    public boolean addRecord(BorrowRecord record) {
        String sql = "INSERT INTO borrow_records (member_id, book_id, borrow_date, due_date, status, fine) " +
                     "VALUES (?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, record.getMemberId());
            ps.setInt(2, record.getBookId());
            ps.setDate(3, Date.valueOf(record.getBorrowDate()));
            ps.setDate(4, Date.valueOf(record.getDueDate()));
            ps.setString(5, record.getStatus());
            ps.setDouble(6, record.getFine());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error adding borrow record: " + e.getMessage(), e);
        }
    }

    public boolean returnBook(int recordId, LocalDate returnDate, double fine) {
        String sql = "UPDATE borrow_records SET return_date=?, status='RETURNED', fine=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(returnDate));
            ps.setDouble(2, fine);
            ps.setInt(3, recordId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error updating return record: " + e.getMessage(), e);
        }
    }

    public BorrowRecord getRecordById(int id) {
        String sql = "SELECT br.*, m.name AS member_name, b.title AS book_title " +
                     "FROM borrow_records br " +
                     "JOIN members m ON br.member_id = m.id " +
                     "JOIN books b ON br.book_id = b.id " +
                     "WHERE br.id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return mapRecord(rs);

        } catch (SQLException e) {
            throw new RuntimeException("Error fetching record: " + e.getMessage(), e);
        }
        return null;
    }

    public List<BorrowRecord> getAllRecords() {
        List<BorrowRecord> records = new ArrayList<>();
        String sql = "SELECT br.*, m.name AS member_name, b.title AS book_title " +
                     "FROM borrow_records br " +
                     "JOIN members m ON br.member_id = m.id " +
                     "JOIN books b ON br.book_id = b.id " +
                     "ORDER BY br.borrow_date DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) records.add(mapRecord(rs));

        } catch (SQLException e) {
            throw new RuntimeException("Error fetching records: " + e.getMessage(), e);
        }
        return records;
    }

    public List<BorrowRecord> getActiveByMember(int memberId) {
        List<BorrowRecord> records = new ArrayList<>();
        String sql = "SELECT br.*, m.name AS member_name, b.title AS book_title " +
                     "FROM borrow_records br " +
                     "JOIN members m ON br.member_id = m.id " +
                     "JOIN books b ON br.book_id = b.id " +
                     "WHERE br.member_id=? AND br.status != 'RETURNED'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, memberId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) records.add(mapRecord(rs));

        } catch (SQLException e) {
            throw new RuntimeException("Error fetching member borrow records: " + e.getMessage(), e);
        }
        return records;
    }

    public List<BorrowRecord> getOverdueRecords() {
        List<BorrowRecord> records = new ArrayList<>();
        String sql = "SELECT br.*, m.name AS member_name, b.title AS book_title " +
                     "FROM borrow_records br " +
                     "JOIN members m ON br.member_id = m.id " +
                     "JOIN books b ON br.book_id = b.id " +
                     "WHERE br.due_date < CURDATE() AND br.status = 'BORROWED'";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) records.add(mapRecord(rs));

        } catch (SQLException e) {
            throw new RuntimeException("Error fetching overdue records: " + e.getMessage(), e);
        }
        return records;
    }

    public int countActiveIssues() {
        String sql = "SELECT COUNT(*) FROM borrow_records WHERE status='BORROWED'";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) return rs.getInt(1);

        } catch (SQLException e) {
            throw new RuntimeException("Error counting issues: " + e.getMessage(), e);
        }
        return 0;
    }

    private BorrowRecord mapRecord(ResultSet rs) throws SQLException {
        BorrowRecord r = new BorrowRecord();
        r.setId(rs.getInt("id"));
        r.setMemberId(rs.getInt("member_id"));
        r.setBookId(rs.getInt("book_id"));
        r.setMemberName(rs.getString("member_name"));
        r.setBookTitle(rs.getString("book_title"));
        r.setBorrowDate(rs.getDate("borrow_date").toLocalDate());
        r.setDueDate(rs.getDate("due_date").toLocalDate());
        Date returnDate = rs.getDate("return_date");
        if (returnDate != null) r.setReturnDate(returnDate.toLocalDate());
        r.setStatus(rs.getString("status"));
        r.setFine(rs.getDouble("fine"));
        return r;
    }
}
